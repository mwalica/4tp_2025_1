package ch.walica.a12_temp181125_4tp1_rv_layoutmanager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class NumberAdapter extends RecyclerView.Adapter<NumberAdapter.NumberViewHolder> {

    private int[] numbers;

    public NumberAdapter(int[] numbers) {
        this.numbers = numbers;
    }

    @NonNull
    @Override
    public NumberViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.number_item, parent, false);
        return new NumberViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NumberViewHolder holder, int position) {
        holder.bind(numbers[position]);
    }

    @Override
    public int getItemCount() {
        return numbers.length;
    }


    public class NumberViewHolder extends RecyclerView.ViewHolder {

        TextView tvNumber;

        public NumberViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNumber = itemView.findViewById(R.id.tvNumber);
        }

        public void bind(int number) {
            tvNumber.setText(String.valueOf(number));
            tvNumber.setTextSize(number * 3);
        }
    }
}

package ch.walica.temp241025_4tp1_listview;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private String[] names = {"Jan", "Karol", "Adam", "Gustaw", "Kornel", "Adrian", "Marcin", "Marek", "Grażyna", "Eliza", "Julia", "Sebastian", "Anna", "Mirosława", "Sabina", "Ela", "Kasia", "Ludmiła", "Lucyna", "Natan", "Mirek", "Lucjan", "Estera", "Kordian", "Grażyna", "Eliza", "Julia", "Sebastian", "Anna", "Mirosława", "Sabina", "Ela", "Kasia", "Ludmiła", "Lucyna", "Natan", "Mirek", "Lucjan", "Estera", "Kordian",};
    private Person[] people = {new Person("Jan"), new Person("Gustaw"), new Person("Adam"), new Person("Jan"), new Person("Gustaw"), new Person("Adam")};
    private Car[] cars = {
            new Car("Fiat", 2021),
            new Car("Ford", 2023),
            new Car("Mazda", 2019),
            new Car("Opel", 2014),
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        listView = findViewById(R.id.listView);

        //ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, names);
        //ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this, R.layout.text_item, names);
        //ArrayAdapter<Person> adapter = new ArrayAdapter<>(MainActivity.this, R.layout.text_item, people);
        ArrayAdapter<Car> adapter = new ArrayAdapter<>(MainActivity.this, R.layout.text_item, cars);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(MainActivity.this, "Wybrano " + cars[i].name() + " " + cars[i].productionYear(), Toast.LENGTH_SHORT).show();
            }
        });


    }
}
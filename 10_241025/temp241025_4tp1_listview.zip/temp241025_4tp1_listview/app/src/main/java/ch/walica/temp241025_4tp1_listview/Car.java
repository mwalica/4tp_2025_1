package ch.walica.temp241025_4tp1_listview;

public record Car(String name, int productionYear) {

    @Override
    public String toString() {
        return name;
    }
}

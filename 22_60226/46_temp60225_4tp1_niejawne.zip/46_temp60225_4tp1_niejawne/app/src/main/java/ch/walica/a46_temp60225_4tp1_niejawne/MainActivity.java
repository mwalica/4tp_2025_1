package ch.walica.a46_temp60225_4tp1_niejawne;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button btnSMS, btnEmail, btnWeb, btnDial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnSMS = findViewById(R.id.btnSMS);
        btnEmail = findViewById(R.id.btnEmail);
        btnWeb = findViewById(R.id.btnWeb);
        btnDial = findViewById(R.id.btnDial);

        btnSMS.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("sms:600392125"));
            intent.putExtra(Intent.EXTRA_TEXT, "To jest treść sms-a");

            try {
                startActivity(Intent.createChooser(intent, "Wybierz app..."));
            } catch(ActivityNotFoundException e) {
                Toast.makeText(this, "msg: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }

        });

        btnEmail.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:"));
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"marek@walica.com.pl", "jan@wp.pl"});
            intent.putExtra(Intent.EXTRA_SUBJECT, "To jest tekst tytuł maila");
            intent.putExtra(Intent.EXTRA_TEXT, "To jest treść wiadomosci e-mail");

            try {
                startActivity(Intent.createChooser(intent, "Wybierz app..."));
            } catch(ActivityNotFoundException e) {
                Toast.makeText(this, "msg: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        btnWeb.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("https://onet.pl"));

            try {
                startActivity(Intent.createChooser(intent, "Wybierz app..."));
            } catch(ActivityNotFoundException e) {
                Toast.makeText(this, "msg: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        btnDial.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:600335897"));

            try {
                startActivity(Intent.createChooser(intent, "Wybierz app..."));
            } catch(ActivityNotFoundException e) {
                Toast.makeText(this, "msg: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
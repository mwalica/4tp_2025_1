package ch.walica.a5_temp301025_4tp_1_listview_crd.model;

import androidx.annotation.NonNull;

import java.util.Random;

public class Person {
    private String name;
    private int age;

    public Person(String name) {
        this.name = name;
        this.age = new Random().nextInt(82) + 18;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    @NonNull
    @Override
    public String toString() {
        return name + " " + age;
    }
}
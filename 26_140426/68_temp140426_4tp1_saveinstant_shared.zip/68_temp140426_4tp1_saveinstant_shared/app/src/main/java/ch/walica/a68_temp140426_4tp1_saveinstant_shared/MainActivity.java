package ch.walica.a68_temp140426_4tp1_saveinstant_shared;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button btnRandomNumber, btnClear;
    TextView tvResult;
    int randomNumber = 0;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnRandomNumber = findViewById(R.id.btnRandomNumber);
        btnClear = findViewById(R.id.btnClear);
        tvResult = findViewById(R.id.tvResult);
        sharedPreferences = getSharedPreferences("shared_prefs", MODE_PRIVATE);

//        if(savedInstanceState != null) {
//            randomNumber = savedInstanceState.getInt("number_1", 0);
//            tvResult.setText(String.valueOf(randomNumber));
//        }

        randomNumber = sharedPreferences.getInt("number_2", 0);
        tvResult.setText(String.valueOf(randomNumber));

        btnRandomNumber.setOnClickListener(view -> {
            randomNumber = new Random().nextInt(101) - 50;
            tvResult.setText(String.valueOf(randomNumber));
            sharedPreferences.edit().putInt("number_2", randomNumber).apply();
        });

        btnClear.setOnClickListener(view -> {
            sharedPreferences.edit().clear().apply();
            recreate();
        });
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("number_1", randomNumber);
    }
}
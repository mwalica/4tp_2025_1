package ch.walica.temp50925_4tp1;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import ch.walica.temp50925_4tp1.model.Car;

public class SecondActivity extends AppCompatActivity {

    private TextView tvCar, tvProductionYear;
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_second);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tvCar = findViewById(R.id.tvCar);
        tvProductionYear = findViewById(R.id.tvProductionYear);
        btnBack = findViewById(R.id.btnBack);

        if(getIntent().hasExtra("car_key")) {
            Car car = (Car) getIntent().getSerializableExtra("car_key");
            tvCar.setText(car.getCompany() + " " + car.getModel());
            tvProductionYear.setText(String.valueOf(car.getProductionYear()));
        }

        btnBack.setOnClickListener(view -> {
            finish();
            overridePendingTransition(R.anim.from_left, R.anim.to_right);
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        super.onSupportNavigateUp();
        overridePendingTransition(R.anim.from_left, R.anim.to_right);
        return true;
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.from_left, R.anim.to_right);
    }
}
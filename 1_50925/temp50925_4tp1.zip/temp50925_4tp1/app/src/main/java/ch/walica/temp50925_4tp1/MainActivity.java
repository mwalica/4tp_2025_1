package ch.walica.temp50925_4tp1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import ch.walica.temp50925_4tp1.model.Car;

public class MainActivity extends AppCompatActivity {

    private EditText etCompany, etModel, etProductionYear;
    private Button btnSend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etCompany = findViewById(R.id.etCompany);
        etModel = findViewById(R.id.etModel);
        etProductionYear = findViewById(R.id.etProductionYear);
        btnSend = findViewById(R.id.btnSend);

        btnSend.setOnClickListener(view -> {
            String company = etCompany.getText().toString().trim();
            String model = etModel.getText().toString().trim();
            String productionYear = etProductionYear.getText().toString().trim();
            if(!company.isEmpty() && !model.isEmpty() && !productionYear.isEmpty() && Integer.parseInt(productionYear) < 2026) {
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra("car_key", new Car(company, model, Integer.parseInt(productionYear)));
                startActivity(intent);
                overridePendingTransition(R.anim.from_right, R.anim.to_left);
            } else {
                Toast.makeText(this, "Proszę poprawnie wypełnić formularz", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
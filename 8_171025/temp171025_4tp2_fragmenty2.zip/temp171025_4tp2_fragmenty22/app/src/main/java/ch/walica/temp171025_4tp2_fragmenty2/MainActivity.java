package ch.walica.temp171025_4tp2_fragmenty2;

import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class MainActivity extends AppCompatActivity {

    Button btnFirst, btnSecond;
    FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnFirst = findViewById(R.id.btnFirst);
        btnSecond = findViewById(R.id.btnSecond);

        fragmentManager = getSupportFragmentManager();

        Fragment firstFragment = new FirstFragment();
        Fragment secondFragment = new SecondFragment();

        fragmentManager.beginTransaction().replace(R.id.fragmentContainer, firstFragment).commit();
        btnFirst.setEnabled(false);
        btnSecond.setEnabled(false);

        btnFirst.setOnClickListener(view -> {
            fragmentManager.beginTransaction().replace(R.id.fragmentContainer, firstFragment).commit();
            btnFirst.setEnabled(false);
            btnSecond.setEnabled(true);
        });

        btnSecond.setOnClickListener(view -> {
            fragmentManager.beginTransaction().replace(R.id.fragmentContainer, secondFragment).commit();
            btnFirst.setEnabled(true);
            btnSecond.setEnabled(false);
        });
    }
}
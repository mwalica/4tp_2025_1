package ch.walica.temp171025_4tp2_fragmenty2;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class SecondFragment extends Fragment {


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_second, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView tvResult = view.findViewById(R.id.tvResult);
        Button btnBack = view.findViewById(R.id.btnBack);

        if (getArguments() != null) {
            String firstName = getArguments().getString("name_key");
            tvResult.setText(firstName);
        }

        btnBack.setOnClickListener(v -> {
            Fragment firstFragment = new FirstFragment();
            requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainer, firstFragment).commit();
        });
    }
}
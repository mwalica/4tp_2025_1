package ch.walica.a40_temp300126_4tp_intent_activityresult;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.annotation.IntegerRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText etEnterNumber;
    private TextView tvMainResult;
    private Button btnSendNumber;

    private ActivityResultLauncher<Integer> launcher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etEnterNumber = findViewById(R.id.etEnteredNumber);
        tvMainResult = findViewById(R.id.tvMainResult);
        btnSendNumber = findViewById(R.id.btnSendNumber);

        launcher = registerForActivityResult(new ActivityResultContract<Integer, Double>() {
            @Override
            public Double parseResult(int resultCode, @Nullable Intent intent) {
                if (resultCode == RESULT_OK) {
                    assert intent != null;
                    return intent.getDoubleExtra("double_key", 0.0);
                }
                return 0.0;
            }

            @NonNull
            @Override
            public Intent createIntent(@NonNull Context context, Integer integer) {
                return new Intent(MainActivity.this, SecondActivity.class).putExtra("int_key", integer);
            }
        }, new ActivityResultCallback<Double>() {
            @Override
            public void onActivityResult(Double doubleResult) {
                tvMainResult.setText(String.valueOf(doubleResult));
            }
        });

        btnSendNumber.setOnClickListener(view -> {
            String number = etEnterNumber.getText().toString().trim();
            if(!number.isEmpty()) {
//                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
//                intent.putExtra("int_key", Integer.parseInt(number));
//                startActivity(intent);
                launcher.launch(Integer.parseInt(number));
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra("car", new Car("Fiat", 2021));
                startActivity(intent);
            } else {
                Toast.makeText(this, "Prosze wpisać liczbę", Toast.LENGTH_SHORT).show();
            }

        });
    }
}
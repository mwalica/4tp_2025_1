package ch.walica.a40_temp300126_4tp_intent_activityresult;

import java.io.Serializable;

public class Car implements Serializable {
    private String name;
    private int productionYear;

    public Car(String name, int productionYear) {
        this.name = name;
        this.productionYear = productionYear;
    }

    public String getName() {
        return name;
    }

    public int getProductionYear() {
        return productionYear;
    }
}

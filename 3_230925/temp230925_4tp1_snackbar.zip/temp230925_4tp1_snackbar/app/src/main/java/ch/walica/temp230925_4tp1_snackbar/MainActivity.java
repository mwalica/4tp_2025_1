package ch.walica.temp230925_4tp1_snackbar;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    private Button btnShow;
    private FloatingActionButton floatingActionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnShow = findViewById(R.id.btnShow);
        floatingActionButton = findViewById(R.id.floatingActionButton);

        Snackbar snackbar = Snackbar.make(btnShow, "Hello", Snackbar.LENGTH_INDEFINITE)
                .setAnchorView(floatingActionButton);

        snackbar.show();

        btnShow.setOnClickListener(view -> {
            Snackbar.make(btnShow, "Hello jestem Snackbar", Snackbar.LENGTH_SHORT)
                    .setBackgroundTint(Color.DKGRAY)
                    .setTextColor(Color.YELLOW)
                    .setAnimationMode(Snackbar.ANIMATION_MODE_SLIDE)
                    .setAnchorView(floatingActionButton)
                    .setAction("Zamknij app", v -> {
                        finish();
                    })
                    .show();
        });

        floatingActionButton.setOnClickListener(view -> {
            snackbar.dismiss();
        });
    }
}
package ch.walica.a30_temp160126_4tp1_json.model;

public class Person {
    private String firstName;
    private int age;
    private Address address;

    public Person(String firstName, int age, Address address) {
        this.firstName = firstName;
        this.age = age;
        this.address = address;
    }

    public String getFirstName() {
        return firstName;
    }

    public int getAge() {
        return age;
    }

    public Address getAddress() {
        return address;
    }
}

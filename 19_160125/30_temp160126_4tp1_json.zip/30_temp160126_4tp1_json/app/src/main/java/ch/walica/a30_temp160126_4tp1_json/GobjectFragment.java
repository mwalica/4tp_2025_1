package ch.walica.a30_temp160126_4tp1_json;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.gson.Gson;

import ch.walica.a30_temp160126_4tp1_json.model.Person;


public class GobjectFragment extends Fragment {



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_gobject, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Gson gson = new Gson();

        Person person = gson.fromJson(Util.loadJSONFromAssets("person.json", requireActivity()), Person.class);
        Toast.makeText(requireContext(), "Person name: " + person.getFirstName(), Toast.LENGTH_SHORT).show();
    }
}
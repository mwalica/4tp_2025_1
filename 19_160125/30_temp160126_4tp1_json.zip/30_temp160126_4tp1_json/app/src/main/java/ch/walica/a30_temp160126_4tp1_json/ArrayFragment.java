package ch.walica.a30_temp160126_4tp1_json;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class ArrayFragment extends Fragment {

    private Button btnShowPersons;
    private ListView listView;
    private List<PersonObj> personsList = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_array, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        btnShowPersons = view.findViewById(R.id.btnShowPersons);
        listView = view.findViewById(R.id.listView);

        try {
            JSONArray persons = new JSONArray(Util.loadJSONFromAssets("persons.json", requireActivity()));
            for (int i = 0; i < persons.length(); i++) {
                JSONObject person = persons.getJSONObject(i);
                String firstName = person.getString("firstName");
                int age = person.getInt("age");
                JSONObject address = person.getJSONObject("address");
                String country = address.getString("country");
                String city = address.getString("city");
                personsList.add(new PersonObj(firstName, city));
            }
        } catch (JSONException error) {
            Toast.makeText(requireContext(), error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
        }

        ArrayAdapter<PersonObj> adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_list_item_1, personsList);
        listView.setAdapter(adapter);
    }


}
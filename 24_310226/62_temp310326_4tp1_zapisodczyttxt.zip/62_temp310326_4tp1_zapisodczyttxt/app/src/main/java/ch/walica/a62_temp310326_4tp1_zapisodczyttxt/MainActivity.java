package ch.walica.a62_temp310326_4tp1_zapisodczyttxt;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText etEnteredText;
    private Button btnSave, btnRead;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etEnteredText = findViewById(R.id.etEnteredText);
        btnSave = findViewById(R.id.btnSave);
        btnRead = findViewById(R.id.btnRead);

        btnSave.setOnClickListener(view -> {
            String enteredText = etEnteredText.getText().toString().trim();
            try {
                File file = new File(getFilesDir(), "info.txt");
                Files.write(file.toPath(), (enteredText + "\n").getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
                etEnteredText.getText().clear();
            } catch(IOException exception) {
                Log.d("my_log", "wyjątek zapisu: " + exception.getLocalizedMessage());
            }
        });

        btnRead.setOnClickListener(view -> {
            try {
                File file = new File(getFilesDir(), "info.txt");
                String content = new String(Files.readAllBytes(file.toPath()));
                Log.d("my_log", "content = " + content);
                List<String> strings = Files.readAllLines(file.toPath());
                Log.d("my_log", "strings = " + strings);
            } catch(IOException exception) {
                Log.d("my_log", "wyjątek odczytu: " + exception.getLocalizedMessage());
            }
        });
    }
}
package ch.walica.a74_temp210426_4tp1_seek_progress_rating;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private SeekBar seekBar;
    private ProgressBar progressBar;
    private RatingBar ratingBar;

    private TextView tvResult;
    private Button btnRandom;

    private int sbValue = 20;
    private int progressValue = 20;
    private float ratingValue = 1.5f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        seekBar = findViewById(R.id.seekBar);
        progressBar = findViewById(R.id.progressBar);
        ratingBar = findViewById(R.id.ratingBar);
        tvResult = findViewById(R.id.tvResult);
        btnRandom = findViewById(R.id.btnRandom);

        seekBar.setProgress(sbValue);
        progressBar.setProgress(progressValue);
        ratingBar.setRating(ratingValue);

        tvResult.setText(sbValue + "");

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                //sbValue = i;
                sbValue = seekBar.getProgress();
                tvResult.setText(sbValue + "");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                progressValue = sbValue;
                progressBar.setProgress(progressValue);
            }
        });

        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                ratingValue = v;
                //ratingValue = ratingBar.getRating();
                tvResult.setText(ratingValue + "");
            }
        });

        btnRandom.setOnClickListener(view -> {
            ratingValue = new Random().nextInt(6);
            ratingBar.setRating(ratingValue);
        });
    }
}
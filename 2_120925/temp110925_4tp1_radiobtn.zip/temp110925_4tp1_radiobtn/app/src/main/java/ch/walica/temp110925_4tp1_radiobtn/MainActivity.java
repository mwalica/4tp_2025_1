package ch.walica.temp110925_4tp1_radiobtn;

import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private RadioGroup radioGroup;
    private TextView tvResult;
    private RadioButton rbChecked;
    private int checkedRadioButtonId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        radioGroup = findViewById(R.id.radioGroup);
        tvResult = findViewById(R.id.tvResult);

        checkedRadioButtonId = radioGroup.getCheckedRadioButtonId();
        checkColorText();

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(@NonNull RadioGroup radioGroup, int i) {
                checkedRadioButtonId = i;
                checkColorText();
            }
        });

    }

    private void checkColorText() {
        rbChecked = findViewById(checkedRadioButtonId);
        tvResult.setText(rbChecked.getText());
        if(checkedRadioButtonId == R.id.radioRed) {
            tvResult.setTextColor(getColor(R.color.red));
        }
        if(checkedRadioButtonId == R.id.radioBlue) {
            tvResult.setTextColor(getColor(R.color.blue));
        }
    }
}
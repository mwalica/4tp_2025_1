package ch.walica.a10_temp141125_4tp_1_rv;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class PersonAdapter extends RecyclerView.Adapter<PersonAdapter.PersonViewHolder> {
    private Person[] people;

    public PersonAdapter(Person[] people) {
        this.people = people;
    }

    @NonNull
    @Override
    public PersonViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.person_item, parent, false);
        return new PersonViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PersonViewHolder holder, int position) {
        holder.bind(people[position]);
    }

    @Override
    public int getItemCount() {
        return people.length;
    }


    public class PersonViewHolder extends RecyclerView.ViewHolder {

        TextView tvName, tvAge;

        public PersonViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvAge = itemView.findViewById(R.id.tvAge);
        }

        public void bind(Person person) {
            tvName.setText(person.getName());
            tvAge.setText(person.getAge() + " lat");
        }
    }
}

package ch.walica.a80_temp4tp2_quiz_egzamin.model;

abstract public class Pytanie {
    protected String question;
    protected int photo;
    protected boolean isCorrect;

    public Pytanie(String question, int photo) {
        this.question = question;
        this.photo = photo;
        this.isCorrect = false;
    }

    public String getQuestion() {
        return question;
    }

    public int getPhoto() {
        return photo;
    }

    public boolean isCorrect() {
        return isCorrect;
    }

    abstract boolean check(String selectedAnswer);
}

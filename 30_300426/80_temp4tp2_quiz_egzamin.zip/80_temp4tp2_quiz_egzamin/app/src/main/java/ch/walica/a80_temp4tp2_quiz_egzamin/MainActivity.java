package ch.walica.a80_temp4tp2_quiz_egzamin;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import ch.walica.a80_temp4tp2_quiz_egzamin.model.PytanieZamkniete;

public class MainActivity extends AppCompatActivity {

    private ImageView ivPhoto;
    private TextView tvQuestion;
    private RadioGroup radioGroup;
    private RadioButton rbA, rbB, rbC;
    private Button btnNext;

    private final PytanieZamkniete[] questions = {
            new PytanieZamkniete("Które to schronisko?", R.drawable.zad1, "Na Rysiance.", "Na Wielkiej Raczy.", "Na Wielkiej Rycerzowej.", "Na Wielkiej Raczy."),
            new PytanieZamkniete("Zwierzę na zdjęciu to", R.drawable.zad2, "owczarek.", "wilk.", "kozica.", "owczarek."),
            new PytanieZamkniete("W oddali są widoczne", R.drawable.zad3, "Himalaje.", "Alpy.", "Tatry.", "Tatry."),
    };

    int count = 0;
    String selectedAnswer = "";
    int selectedIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ivPhoto = findViewById(R.id.ivPhoto);
        tvQuestion = findViewById(R.id.tvQuestion);
        radioGroup = findViewById(R.id.radioGroup);
        rbA = findViewById(R.id.rgA);
        rbB = findViewById(R.id.rgB);
        rbC = findViewById(R.id.rgC);
        btnNext = findViewById(R.id.btnNext);

        setScreen();

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(@NonNull RadioGroup radioGroup, int i) {
                RadioButton selectedRadio = findViewById(i);
                selectedAnswer = selectedRadio.getText().toString();
            }
        });


        btnNext.setOnClickListener(view -> {
            boolean state = questions[selectedIndex].check(selectedAnswer);
            if(state) {
                count++;
            }

            if(selectedIndex == questions.length -1) {
                selectedIndex = 0;
            } else {
                selectedIndex++;
            }

            setScreen();
        });


    }

    private void setScreen() {
        ivPhoto.setImageResource(questions[selectedIndex].getPhoto());
        tvQuestion.setText(questions[selectedIndex].getQuestion());
        rbA.setText(questions[selectedIndex].getAnswerA());
        rbB.setText(questions[selectedIndex].getAnswerB());
        rbC.setText(questions[selectedIndex].getAnswerC());
        rbA.setChecked(false);
        rbB.setChecked(false);
        rbC.setChecked(false);
    }
}
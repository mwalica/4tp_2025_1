package ch.walica.a80_temp4tp2_quiz_egzamin.model;

public class PytanieZamkniete extends Pytanie{

    private String answerA;
    private String answerB;
    private String answerC;
    private String correctAnswer;

    public PytanieZamkniete(String question, int photo, String answerA, String answerB, String answerC, String correctAnswer) {
        super(question, photo);
        this.answerA = answerA;
        this.answerB = answerB;
        this.answerC = answerC;
        this.correctAnswer = correctAnswer;
    }

    public String getAnswerA() {
        return answerA;
    }

    public String getAnswerB() {
        return answerB;
    }

    public String getAnswerC() {
        return answerC;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    @Override
    public boolean check(String selectedAnswer) {
        isCorrect = selectedAnswer.equals(correctAnswer);
        return isCorrect;
    }
}

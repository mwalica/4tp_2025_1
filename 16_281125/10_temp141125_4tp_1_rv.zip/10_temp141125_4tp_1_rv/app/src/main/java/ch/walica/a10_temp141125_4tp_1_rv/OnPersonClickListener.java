package ch.walica.a10_temp141125_4tp_1_rv;

public interface OnPersonClickListener {
    public void onPersonClick(int position);
}

package ch.walica.a71_temp170426_4tp1_listview;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    FloatingActionButton fabAdd;
    ListView listView;
    List<Integer> numbers = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        fabAdd = findViewById(R.id.fabAdd);
        listView = findViewById(R.id.listView);

        numbers.add(23);
        numbers.add(123);

        ArrayAdapter<Integer> adapter = new ArrayAdapter<>(MainActivity.this, R.layout.list_item, numbers);

        listView.setAdapter(adapter);

        fabAdd.setOnClickListener(view -> {
            numbers.add(new Random().nextInt(123));
            adapter.notifyDataSetChanged();
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                numbers.remove(numbers.get(i));
                adapter.notifyDataSetChanged();
            }
        });
    }
}
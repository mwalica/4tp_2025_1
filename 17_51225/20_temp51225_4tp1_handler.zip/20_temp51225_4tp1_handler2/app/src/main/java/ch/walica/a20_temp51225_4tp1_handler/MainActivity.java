package ch.walica.a20_temp51225_4tp1_handler;

import static android.view.View.INVISIBLE;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView tvText1, tvText2;
    private Button btnStartStop;
    private Handler handler = new Handler();
    private Random random = new Random();
    private boolean isRunning = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tvText1 = findViewById(R.id.tvText1);
        tvText2 = findViewById(R.id.tvText2);
        btnStartStop = findViewById(R.id.btnStartStop);

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, "Jestem", Toast.LENGTH_SHORT).show();
                tvText1.setText("Hello po 2 sekundach");
            }
        }, 2000);

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                tvText1.setVisibility(INVISIBLE);
            }
        }, 4000);


        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                tvText2.append("Hello ");
                tvText2.setTextColor(Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256)));
                handler.postDelayed(this, 1000);
            }
        };

        handler.post(runnable);


        btnStartStop.setOnClickListener(view -> {
            if(isRunning) {
                handler.removeCallbacks(runnable);
                btnStartStop.setText("Start");
                isRunning = false;
            } else {
                handler.post(runnable);
                btnStartStop.setText("Stop");
                isRunning = true;
            }

        });
    }
}
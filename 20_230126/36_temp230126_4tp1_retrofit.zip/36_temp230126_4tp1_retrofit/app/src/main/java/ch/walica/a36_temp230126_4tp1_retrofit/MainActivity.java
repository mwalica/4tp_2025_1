package ch.walica.a36_temp230126_4tp1_retrofit;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ProgressBar progressBar;
    Spinner spinner;
    String[] regions = {"europe", "asia", "africa", "americas", "oceania"};
    String selected = "europe";

    List<Country> countries = new ArrayList<>();
    ApiInterface apiInterface;

    ArrayAdapter<Country> adapter2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        listView = findViewById(R.id.listView);
        progressBar = findViewById(R.id.progressBar);
        spinner = findViewById(R.id.spinner);

        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_spinner_dropdown_item, regions);
        spinner.setAdapter(adapter1);

        adapter2 = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, countries);
        listView.setAdapter(adapter2);

        Retrofit retrofit = ApiClient.getRetrofit();
        apiInterface = retrofit.create(ApiInterface.class);



        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selected = regions[i];
                fetchCountries();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        fetchCountries();


        
        
    }
    
    private void fetchCountries() {
        progressBar.setVisibility(VISIBLE);
        Call<List<Country>> call = apiInterface.getCountries(selected);
        call.enqueue(new Callback<List<Country>>() {
            @Override
            public void onResponse(Call<List<Country>> call, Response<List<Country>> response) {
                if(!response.isSuccessful()) {
                    Toast.makeText(MainActivity.this, "Kod: " + response.code(), Toast.LENGTH_SHORT).show();
                    return;
                }
                countries.clear();
                assert response.body() != null;
                countries.addAll(response.body());
                progressBar.setVisibility(GONE);
                adapter2.notifyDataSetChanged();
            }

            @Override
            public void onFailure(Call<List<Country>> call, Throwable t) {
                Toast.makeText(MainActivity.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
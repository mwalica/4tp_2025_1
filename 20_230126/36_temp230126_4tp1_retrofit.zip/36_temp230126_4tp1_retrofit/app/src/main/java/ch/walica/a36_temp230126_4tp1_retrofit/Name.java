package ch.walica.a36_temp230126_4tp1_retrofit;

public class Name {
    private String common;
    private String official;

    public Name(String common, String official) {
        this.common = common;
        this.official = official;
    }

    public String getCommon() {
        return common;
    }

    public String getOfficial() {
        return official;
    }
}

package ch.walica.a36_temp230126_4tp1_retrofit;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface ApiInterface {

    @GET("europe")
    Call<List<Country>> getEuropeCountries();

    @GET("{region}")
    Call<List<Country>> getCountries(@Path("region") String region);
}

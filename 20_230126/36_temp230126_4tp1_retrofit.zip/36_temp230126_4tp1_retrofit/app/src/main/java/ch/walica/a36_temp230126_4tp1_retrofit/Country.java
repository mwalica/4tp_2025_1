package ch.walica.a36_temp230126_4tp1_retrofit;

import androidx.annotation.NonNull;

public class Country {
    private Name name;
    private String[] capital;
    private String flag;

    public Country(Name name, String[] capital, String flag) {
        this.name = name;
        this.capital = capital;
        this.flag = flag;
    }

    public Name getName() {
        return name;
    }

    public String[] getCapital() {
        return capital;
    }

    public String getFlag() {
        return flag;
    }

    @NonNull
    @Override
    public String toString() {
        return name.getCommon() + (capital != null ? capital[0] : "") + " " + flag;
    }
}
